# Propositional Quantifiers mechanized in Coq

This project mechanizes Pitts' construction and soundness proof of propositional
quantifiers for intuitionistic propositional logic and extracts from it an OCaml program allowing to compute propositional quantifiers for some example formulas.

## Build instructions
In a shell, do `make`. To generate HTML documentation in the `html` subfolder, do `make doc`.

Tested with Coq v8.15.2, OCaml v4.13.1, dune v3.4.1.

## Usage

After building the project, an executable will be available under `./_build/default/bin/propquant.exe`. This program may be run without arguments for more details on its usage.

## Dependencies
- coq-stdpp
- coq-color
- exenum (only to test the extracted code)

## Documentation

Using the [Coqdocjs](https://github.com/coq-community/coqdocjs) package, see LICENSE-doc file.
