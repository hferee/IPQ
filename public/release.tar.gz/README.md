# Propositional Quantifiers in Coq

This project mechanizes Pitts' construction and soundness proof of propositional
quantifiers for intuitionistic propositional logic.



## Build instructions
In a shell, do `make`. To generate HTML documentation, do `make doc`.

Tested with Coq v8.15.2 (compiled with OCaml v4.13.1).

## Dependencies
- coq-stdpp
- coq-color
- exenum (only to test the extracted code)

## Documentation

Using the [Coqdocjs](https://github.com/coq-community/coqdocjs) package, see LICENSE-doc file.
